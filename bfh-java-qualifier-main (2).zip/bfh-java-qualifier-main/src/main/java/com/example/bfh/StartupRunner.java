package com.example.bfh;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;

@Component
public class StartupRunner implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(StartupRunner.class);

    private final AppProps props;
    private final RestTemplate restTemplate;

    public StartupRunner(AppProps props) {
        this.props = props;
        this.restTemplate = new RestTemplate();
    }

    @Override
    public void run(String... args) throws Exception {
        
        String generateUrl = "https://bfhldevapigw.healthrx.co.in/hiring/generateWebhook/JAVA";

        Map<String, String> payload = Map.of(
                "name", props.getName(),
                "regNo", props.getRegNo(),
                "email", props.getEmail()
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, String>> request = new HttpEntity<>(payload, headers);

        log.info("Requesting webhook for regNo={} ...", props.getRegNo());
        ResponseEntity<GenerateResponse> resp = restTemplate.exchange(
                generateUrl, HttpMethod.POST, request, GenerateResponse.class);

        if (!resp.getStatusCode().is2xxSuccessful() || resp.getBody() == null) {
            throw new IllegalStateException("Failed to generate webhook: " + resp.getStatusCode());
        }

        GenerateResponse body = resp.getBody();
        String webhookUrl = body.getWebhook();
        String accessToken = body.getAccessToken();
        log.info("Received webhook={}, accessToken(length={})", webhookUrl, accessToken != null ? accessToken.length() : 0);

        // 2) Choose SQL based on last two digits of regNo
        String lastTwoDigits = props.getRegNo().replaceAll("\\D", "");

        if (lastTwoDigits.length() >= 2) {
            lastTwoDigits = lastTwoDigits.substring(lastTwoDigits.length() - 2);
        }
        int last2 = lastTwoDigits.isEmpty() ? 0 : Integer.parseInt(lastTwoDigits);
        boolean isOdd = (last2 % 2) == 1;

        String finalQuery = isOdd ? SqlSolutions.QUESTION1_SQL : SqlSolutions.QUESTION2_SQL;

        if (!StringUtils.hasText(finalQuery) || finalQuery.contains("TODO")) {
            log.warn("Final SQL query is not filled. Please update SqlSolutions with your actual SQL before running.");
        }

        
        Path out = Path.of("finalQuery.sql");
        Files.writeString(out, finalQuery);
        log.info("Stored final SQL at {}", out.toAbsolutePath());

        
        HttpHeaders submitHeaders = new HttpHeaders();
        submitHeaders.setContentType(MediaType.APPLICATION_JSON);
        String authValue = (props.getBearerPrefix() == null ? "" : props.getBearerPrefix()) + accessToken;
        submitHeaders.set("Authorization", authValue);

        Map<String, String> submitBody = Map.of("finalQuery", finalQuery);
        HttpEntity<Map<String, String>> submitReq = new HttpEntity<>(submitBody, submitHeaders);

        log.info("Submitting final SQL to webhook: {}", webhookUrl);
        ResponseEntity<String> submitResp = restTemplate.exchange(
                webhookUrl, HttpMethod.POST, submitReq, String.class);

        log.info("Submission status={}, body={}", submitResp.getStatusCode(), submitResp.getBody());
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class GenerateResponse {
        private String webhook;
        private String accessToken;

        public String getWebhook() { return webhook; }
        public void setWebhook(String webhook) { this.webhook = webhook; }

        public String getAccessToken() { return accessToken; }
        public void setAccessToken(String accessToken) { this.accessToken = accessToken; }
    }

}

@Configuration
@ConfigurationProperties(prefix = "app")
class AppProps {
    private String name;
    private String regNo;
    private String email;
    private String bearerPrefix;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getRegNo() { return regNo; }
    public void setRegNo(String regNo) { this.regNo = regNo; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getBearerPrefix() { return bearerPrefix; }
    public void setBearerPrefix(String bearerPrefix) { this.bearerPrefix = bearerPrefix; }
}
