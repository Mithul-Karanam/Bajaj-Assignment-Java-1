package com.example.bfh;

public final class SqlSolutions {
    private SqlSolutions() {}

    
    public static final String QUESTION1_SQL = """
-- TODO: paste the final SQL for Question 1 here.
-- Example:
-- SELECT col1, COUNT(*) FROM table_name GROUP BY col1 ORDER BY COUNT(*) DESC;
""";

    
    public static final String QUESTION2_SQL = """
    SELECT MAX(salary) AS second_highest_salary
    FROM employees
    WHERE salary < (SELECT MAX(salary) FROM employees);



""";
}
